<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <script src="style/script.js" defer></script>
    <link rel="stylesheet" href="style/styleLoja.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css"
        integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css"
        integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>oficina</title>
</head>

<body>
    <header>
        <div class="menu">
            <div class="top">
                <div class="social">social</div>
                <div class="logo"><img src="img/Design_sem_nome.png" alt=""></div>
                <div class="custom-user">
                    <div class="login">login</div>
                    <ul class="links">
                        <a href="">upload produtos</a>
                        <a href="">upload serviços</a>
                        <a href=""></a>
                        <a href=""></a>
                        <a href=""></a>
                    </ul>
                </div>
            </div>
            <div class="menu-ul">
                <div class="inner-l"></div>
                <ul>
                    <a href="index.php?acao=home">início</a>
                    <a href="index.php?acao=home#sobre">sobre</a>
                    <a href="index.php?acao=servicos">serviços</a>
                    <a href="index.php?acao=loja">loja</a>
                    <a href="index.php?acao=contato">contato</a>
                    <a href="index.php?acao=faq">faq</a>
                    <a href="index.php?acao=vaga">trabalhe conosco</a>
                    <div class="car">
                        <img src="img/img_site/output.png" alt="">
                    </div>
                </ul>
                <div class="inner-r"></div>
            </div>
            

        </div>
    </header>
    <div class="menu-ul-alternative">
        <ul>
            <h1>(LOGO)</h1>
            <a href="index.php?acao=home">início</a>
            <a href="index.php?acao=home#sobre">sobre</a>
            <a href="index.php?acao=servicos">serviços</a>
            <a href="index.php?acao=loja">loja</a>
            <a href="index.php?acao=contato">contato</a>
            <a href="index.php?acao=faq">faq</a>
            <a href="index.php?acao=vaga">trabalhe conosco</a>
        </ul>
    </div>