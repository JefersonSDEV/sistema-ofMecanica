<!--
    <div class="box-serv-idx">
        <a href="index.php?acao=servicosPrev" class="serv">
            <img src="quem_somos.png" alt="">
        </a>
        <span class="aniInfos">
            nome do produto (nome com descrição)
        </span>
    </div>-->
    
<div class="containerServ">
<?php

include_once("banco/conect.php");
$select = "SELECT * FROM servicos ORDER BY id_serv DESC LIMIT 78";
    try {
        $result = $conect->prepare($select);
        $cont = 1;
        $result->execute();
        $contar = $result->rowCount();
        if ($contar > 0) {
            while ($show = $result->FETCH(PDO::FETCH_OBJ)) {
                ?>
    <a href="index.php?acao=servicosPrev&id=<?php echo $show->id_serv?>" title="<?php echo $show->nome_serv?>">
        <img src="img/servicos/<?php echo $show->img_serv?>" alt="<?php echo $show->img_serv?>">
        <span class="aniInfos">
        <?php echo $show->nome_serv?>
        </span>
    </a><?php
                    }
                } else {

                }
            } catch (PDOException $e) {
                echo "<strong>ERRO DE PDO = </strong>" . $e->getMessage();
            }
        ?>
</div>