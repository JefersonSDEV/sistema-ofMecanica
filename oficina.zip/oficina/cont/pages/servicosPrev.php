<div class="rowPrev">
<?php
    include('banco/conect.php');

    $id = filter_input(INPUT_GET, 'id', FILTER_DEFAULT);
    $select = "SELECT * FROM  servicos WHERE id_serv=:id ";

    try {
        $resultado = $conect->prepare($select);
        $resultado->bindParam(':id', $id, PDO::PARAM_INT);
        $resultado->execute();

        $contar = $resultado->rowCount();
        if ($contar > 0) {
            while ($show = $resultado->FETCH(PDO::FETCH_OBJ)) {
                $idConts = $show->id_serv;
                $nome = $show->nome_serv;
                $valor = $show->valor_serv;
                $desc = $show->desc_serv;
                $img = $show->img_serv;
            }
        } else {
            echo "não encontramos nada no nosso banco de dados";
        }
    } catch (PDOException $e) {
        echo "<strong>ERRO DE SELECT NO PDO = </strong>" . $e->getMessage();
    }
    ?>
    <div class="imgServPrev">
        <img src="img/servicos/<?php echo $img;?>" alt="<?php echo $img;?>">
    </div>
    <div class="textServPrev">
        <h1 class="h1Prev"><?php echo $nome;?></h1>
        <span id="cont-span">R$: <?php echo $valor;?></span>
        <a id="contrato" href="index.php?acao=contratar">Contratar</a>
        <p class="txtPrev">
            <?php echo $desc;?>
        </p>
    </div>
</div>
<div class="row-comand">
    <div class="comand">
        <?php if($idConts == 79){?>
            <?php echo'<a href="#';?><?php echo'" class="prev" title="ver próximo serviço"><</a>';?>;
        <?php }else{?> 
            <?php echo'<a href="index.php?acao=servicosPrev&id=';?> <?php echo $idConts -1;?><?php echo'" class="prev" title="ver próximo serviço"><</a>';?>;
            <?php }?>

            <?php if($idConts == 117){?>
            <?php echo'<a href="#';?><?php echo'" class="next" title="ver próximo serviço">></a>';?>;
        <?php }else{?> 
            <?php echo'<a href="index.php?acao=servicosPrev&id=';?> <?php echo $idConts +1;?><?php echo'" class="next" title="ver próximo serviço">></a>';?>;
            <?php }?>
    </div>
</div>
<style>
    .rowPrev {
        position: relative;
        width: 100%;
        min-height: 500px;
        display: flex;
        justify-content: center;
    }
</style>