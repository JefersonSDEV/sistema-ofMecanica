<div class="contato">
    <div class="form-contact">
        <h2>Contate-nos</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="text" name="" id="" placeholder="nome completo...">
            <input type="email" name="" id="" placeholder="digite um email...">
            <input type="text" name="" id="" placeholder="assunto...">
            <textarea name="" id="" cols="30" rows="7" placeholder="digite sua mensagem..."></textarea>
            <button type="submit">enviar</button>
        </form>
    </div>
</div>