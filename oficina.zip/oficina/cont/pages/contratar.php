<div class="rowPrevs" style="align-items:center; padding: 20px;">
    <form id="formulario" action="" method="post" enctype="multipart/form-data">
        <input class="input" type="text" name="nome" placeholder="Nome Completo...">
        <input class="input" type="text" name="fone" id="fone" placeholder="Telefone ex: (xx)x xxxx-xxxx" maxlength="16">
        <input class="input" type="email" name="email" id="email" placeholder="Email...">
        <input class="input" type="text" name="nomeService" placeholder="Nome do Serviço...">
        <input class="input" type="datetime-local" name="horario" id="data">
        <input id="rua" class="input" type="text" name="rua" placeholder="Nome da Rua...">
        <p id="forma-pag" onclick="forma()">
            forma de pagamento
        </p>
        <div class="forma-pagamento">
            <div class="pag-table" onclick="clickt()">pix</div>
            <div class="pag-table" onclick="clickt()">crédito</div>
            <div class="pag-table" onclick="clickt()">débito</div>
            <div class="pag-table" onclick="clickt()">boleto</div>
            <div class="pag-table" onclick="clickt()">cancelar</div>
        </div>
        <button class="contrate"  id="submit" type="submit">contratar</button>
    </form>
</div>