<div class="faq">
    <div class="quests">
        <h3>Faq Dúvidas mais frequentes</h3>
        <div class="faq-q">
            <span onclick="quest1()">quest 1</span>
        </div>
        <div class="faq-q">
            <span onclick="quest2()">quest 2</span>
        </div>
        <div class="faq-q">
            <span onclick="quest3()">quest 3</span>
        </div>
        <div class="faq-q">
            <span onclick="quest4()">quest 4</span>
        </div>
        <div class="faq-q">
            <span onclick="quest5()">quest 5</span>
        </div>
        <div class="faq-q">
            <span onclick="quest6()">quest 6</span>
        </div>
        <div class="faq-q">
            <span onclick="quest7()">quest 7</span>
        </div>
        <div class="faq-q">
            <span onclick="quest8()">quest 8</span>
        </div>
        <div class="faq-q">
            <span onclick="quest9()">quest 9</span>
        </div>
        <div class="faq-q">
            <span onclick="quest10()">quest 10</span>
        </div>
        <div class="faq-q">
            <span onclick="quest11()">quest 11</span>
        </div>
        <div class="faq-q">
            <span onclick="quest12()">quest 12</span>
        </div>
        <div class="faq-q">
            <span onclick="quest13()">quest 13</span>
        </div>
    </div>

    <div class="resp">
        <div id="quest1">
            <span>quest 1</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

        <div id="quest2">
            <span>quest 2</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

        <div id="quest3">
            <span>quest 3</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

        <div id="quest4">
            <span>quest 4</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

        <div id="quest5">
            <span>quest 5</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

        <div id="quest6">
            <span>quest 6</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

        <div id="quest7">
            <span>quest 7</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

        <div id="quest8">
            <span>quest 8</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

        <div id="quest9">
            <span>quest 9</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

        <div id="quest10">
            <span>quest 10</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

        <div id="quest11">
            <span>quest 11</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

        <div id="quest12">
            <span>quest 12</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

        <div id="quest13">
            <span>quest 13</span>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint nihil necessitatibus
                praesentium molestiae
                repudiandae maiores consequuntur molestias officia recusandae, eum cupiditate harum aperiam distinctio
                animi
                quas repellendus eligendi totam ipsa!
            </p>
        </div>

    </div>
</div>
<div class="faq-area">
    <h3>Faq, crie perguntas desenvolva soluções</h3>
    <form action="" method="post" enctype="multipart/form-data">
        <input type="text" placeholder="qual a dúvida?">
        <textarea name="" id="" cols="30" rows="7" placeholder="resposta ou solução"></textarea>
        <button type="submit">enviar</button>
    </form>
</div>
<a id="faq">+</a>
<style>
    .faq {
        width: 100%;
        display: flex;
        padding: 20px;
    }

    .quests {
        width: 40%;
        min-height: 500px;
        max-height: 700px;
        margin-right: 5px;
        display: flex;
        align-items: center;
        color: #fff;
        flex-direction: column;
        padding: 10px;
        background: #222;
    }

    .resp {
        width: 60%;
        min-height: 500px;
        margin-left: 5px;
        display: flex;
        align-items: center;
        color: #fff;
        flex-direction: column;
        padding: 10px;
        background: #222;
    }

    .faq-q {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        padding: 5px;
        border-bottom: 1px solid #ccc;
    }

    .faq-q span {
        width: 100%;
        cursor: pointer;
    }

    .resp div {
        width: 100%;
        display: none;
        text-align: justify;
        padding: 5px 0;
        border-bottom: 1px solid #ccc;
    }

    .faq span {
        width: 100%;
        font-size: 15px;
        text-transform: uppercase;
    }

    .faq p {
        color: #ccccccdd;
        font-style: italic;
    }

    .faq h3,
    .faq-area h3 {
        color: #fff;
        font-weight: 300;
        position: relative;
        margin-bottom: 30px;
        text-align: center;
        text-transform: uppercase;
    }

    .faq h3::after,
    .faq-area h3::after {
        content: "";
        position: absolute;
        width: 200px;
        height: 3px;
        background-color: #ff0000;
        bottom: -10px;
        left: 0;
        right: 0;
        margin: auto;
    }

    .faq-area {
        position: fixed;
        width: 100%;
        height: 100%;
        background: #000000d0;
        display: none;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }

    .faq-area form {
        width: 40%;
        display: flex;
        justify-content: center;
        flex-direction: column;
        padding: 20px;
    }

    .faq-area form input,
    .faq-area form textarea {
        width: 100%;
        padding: 5px;
        padding-left: 10px;
        background: transparent;
        border: none;
        border: 1px solid #ff0000;
        border-radius: 5px;
        margin: 10px 0;
        color: #ff0000;
    }

    .faq-area form button {
        width: 100px;
        padding: 10px;
        text-transform: uppercase;
        font-weight: 700;
        background: transparent;
        border: none;
        border: 1px solid #ff0000;
        border-radius: 5px;
        margin: 10px 0;
        color: #ff0000;
    }

    .faq-area form button:hover {
        background: #ff0000;
        border: 1px solid #fff;
        color: #fff;
    }

    #faq {
        position: fixed;
        bottom: 20px;
        left: 20px;
        width: 30px;
        height: 30px;
        border-radius: 100%;
        background: red;
        border: 1px solid #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        z-index: 50;
        text-decoration: none;
        font-weight: 700;
        cursor: pointer;
    }

    #faq:hover {
        background: #fff;
        color: red;
        border: 1px solid red;
    }
</style>
<script>

    var ques1 = document.querySelector("#quest1");
    var ques2 = document.querySelector("#quest2");
    var ques3 = document.querySelector("#quest3");
    var ques4 = document.querySelector("#quest4");
    var ques5 = document.querySelector("#quest5");
    var ques6 = document.querySelector("#quest6");
    var ques7 = document.querySelector("#quest7");
    var ques8 = document.querySelector("#quest8");
    var ques9 = document.querySelector("#quest9");
    var ques10 = document.querySelector("#quest10");
    var ques11 = document.querySelector("#quest11");
    var ques12 = document.querySelector("#quest12");
    var ques13 = document.querySelector("#quest13");

    function quest1() {
        if (ques1.style.display == "none") {
            ques1.style.display = "block";
        } else {
            ques1.style.display = "none";
        }
    }
    function quest2() {
        if (ques2.style.display == "none") {
            ques2.style.display = "block";
        } else {
            ques2.style.display = "none";
        }
    }
    function quest3() {
        if (ques3.style.display == "none") {
            ques3.style.display = "block";
        } else {
            ques3.style.display = "none";
        }
    }
    function quest4() {
        if (ques4.style.display == "none") {
            ques4.style.display = "block";
        } else {
            ques4.style.display = "none";
        }
    }
    function quest5() {
        if (ques5.style.display == "none") {
            ques5.style.display = "block";
        } else {
            ques5.style.display = "none";
        }
    }
    function quest6() {
        if (ques6.style.display == "none") {
            ques6.style.display = "block";
        } else {
            ques6.style.display = "none";
        }
    }
    function quest7() {
        if (ques7.style.display == "none") {
            ques7.style.display = "block";
        } else {
            ques7.style.display = "none";
        }
    }
    function quest8() {
        if (ques8.style.display == "none") {
            ques8.style.display = "block";
        } else {
            ques8.style.display = "none";
        }
    }
    function quest9() {
        if (ques9.style.display == "none") {
            ques9.style.display = "block";
        } else {
            ques9.style.display = "none";
        }
    }
    function quest10() {
        if (ques10.style.display == "none") {
            ques10.style.display = "block";
        } else {
            ques10.style.display = "none";
        }
    }
    function quest11() {
        if (ques11.style.display == "none") {
            ques11.style.display = "block";
        } else {
            ques11.style.display = "none";
        }
    }
    function quest12() {
        if (ques12.style.display == "none") {
            ques12.style.display = "block";
        } else {
            ques12.style.display = "none";
        }
    }
    function quest13() {
        if (ques13.style.display == "none") {
            ques13.style.display = "block";
        } else {
            ques13.style.display = "none";
        }
    }
    var faq = document.getElementById("faq");
    var faqArea = document.querySelector(".faq-area");
    faq.addEventListener("click", function () {
        if (faqArea.style.display == "none") {
            faqArea.style.display = "flex";
        } else {
            faqArea.style.display = "none";
        }
    });
</script>