<div class="loja">
    <h2><b>PRODUTOS</b> EM DESTAQUE</h2>
    <div class="slider js-slider">
        <?php
        include_once("banco/conect.php");
        $select = "SELECT * FROM loja ORDER BY id_prod ASC LIMIT 30";
        try {
            $result = $conect->prepare($select);
            $cont = 1;
            $result->execute();
            $contar = $result->rowCount();
            if ($contar > 0) {
                while ($show = $result->FETCH(PDO::FETCH_OBJ)) {
                    ?>
                    <div class="card">
                        <div class="like"></div>
                        <img class="product" src="img/produtos/<?php echo $show->art_prod ?>"
                            alt="Foto do produtos - <?php echo $show->art_prod ?>" />
                        <h4 class="title" title="<?php echo $show->nome_prod ?>"><?php echo $show->nome_prod ?></h4>
                        <div class="price">
                            <?php
                            if ($show->valorAnt_prod == "") {
                                ?>
                                <?php
                            } else {
                                ?>
                                <h5>R$
                                    <?php echo " $show->valorAnt_prod"; ?>
                                </h5>
                                <?php
                            }
                            ?>
                            <h5>
                                R$
                                <?php echo $show->valor_prod ?>
                            </h5>
                        </div>
                        <a class="button">Carrinho</a>
                    </div>
                    <?php
                }
            } else {

            }
        } catch (PDOException $e) {
            echo "<strong>ERRO DE PDO = </strong>" . $e->getMessage();
        }
        ?>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"
        integrity="sha512-h9kKZlwV1xrIcr2LwAPZhjlkx+x62mNwuQK5PAu9d3D+JXMNlGx8akZbqpXvp0vA54rz+DrqYVrzUGDMhwKmwQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"
        integrity="sha512-fDGBclS3HUysEBIKooKWFDEWWORoA20n60OwY7OSYgxGEew9s7NgDaPkj7gqQcVXnASPvZAiFW8DiytstdlGtQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"
        integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script type="text/javascript" src="style/scriptLoja.js"></script>
</div>
<div class="lojaCont">
    <?php
    include_once("banco/conect.php");
    $select = "SELECT * FROM loja ORDER BY id_prod DESC LIMIT 1000";
    try {
        $result = $conect->prepare($select);
        $cont = 1;
        $result->execute();
        $contar = $result->rowCount();
        if ($contar > 0) {
            while ($show = $result->FETCH(PDO::FETCH_OBJ)) {
                ?>
                <a href="index.php?acao=ProdutosPrev&id=<?php echo $show->id_prod?>">
                    <img src="img/produtos/<?php echo $show->art_prod ?>" alt="">
                    <h4 class="title" title="<?php echo $show->nome_prod ?>">
                        <?php echo $show->nome_prod ?>
                    </h4>
                    <div class="price">
                        <?php
                        if ($show->valorAnt_prod == "") {
                            ?>
                            <?php
                        } else {
                            ?>
                            <h5>R$
                                <?php echo " $show->valorAnt_prod"; ?>
                            </h5>
                            <?php
                        }
                        ?>
                        <h5>
                            R$
                            <?php echo $show->valor_prod ?>
                        </h5>
                    </div>
                </a>
                <?php
            }
        } else {

        }
    } catch (PDOException $e) {
        echo "<strong>ERRO DE PDO = </strong>" . $e->getMessage();
    }
    ?>
</div>