<div class="contato">
    <div class="form-contact">
    <div class="curriculo">
        <h3>faça já sua inscrição</h3>
    </div>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="text" name="nome" id="nome" placeholder="Digite seu Nome Completo...">
            <span role="alert" id="nameError1" aria-hidden="true">
                Este campo é obrigatório*
            </span>

            <input type="email" name="email" id="email" placeholder="Digite seu Email...">
            <span role="alert" id="nameError2" aria-hidden="true">
                Este campo é obrigatório*
            </span>

            <input type="text" name="end" id="end" placeholder="Digite seu Endereço...">
            <span role="alert" id="nameError3" aria-hidden="true">
                Este campo é obrigatório*
            </span>

            <input type="text" name="fone" id="fone" placeholder="Digite seu Número de Contato...">
            <span role="alert" id="nameError4" aria-hidden="true">
                Este campo é obrigatório*
            </span>

            <input type="file" name="img" id="img" style="display:none;">
            <div class="btn-contact">
                <label for="img">Arquivo</label>
                <span role="alert" id="nameError5" aria-hidden="true">
                    O arquivo é obrigatório*
                </span>
                <button id="submit" type="submit">Enviar</button>
            </div>
        </form>
    </div>
</div>