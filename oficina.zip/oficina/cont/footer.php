<footer>
    <div class="social-F">social</div>
    <div class="contact-F">(85) 9 9999-9999</div>
    <p>© 2023 - Todos os Direitos Reservados</p>
</footer>
<a href="#" id="top"></a>
</body>

</html>